import { Routes } from '@angular/router';
import { ChatComponent } from './chat/chat.component';

export const routes: Routes = [
  { path: '', component: ChatComponent },
  // Add other routes here as needed
];
