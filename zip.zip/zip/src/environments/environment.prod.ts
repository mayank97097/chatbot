export const environment = {
  production: true,
  // Add any other production-specific environment variables here
};
